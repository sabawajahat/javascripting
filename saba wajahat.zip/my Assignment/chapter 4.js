//Chapter:4
//Q:1
// var  user = 'John', age = 25, message = 'Hello';
//alert(user+age+message);

//Q:2
//legal variables
// var name;
// var myName;
// var $age;
// var test123;
// var father_name;

//illegal variables
// name="ali";
// var father-name;
// var 2b;
// var var=5;
// var -name;

//Q:3
// document.write("<p style='font-size:30px;'>" + "Rules for naming JSvariables" + "</p>" + "<br/>");
// document.write("<p>" + "Variable names can only contain" + " " + "," +
// " " + "numbers" + "," + " " + "$ and" + " " + " _" + " " + "." + " " +
// "For example :"+ " " + "$my" + " " + "_ 1st Variable" + "<br/>" +
// "Variables must begin with a letter, $ or _ . For Example: $name, _name or name" + "</br>" + "Variable names are case" + " " +
// "sensitive" + "</br>" + "Variable names should not be JS" + " " +
// "Keywords" + "</p>");