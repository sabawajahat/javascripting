//chapter:1
//Q 1
// alert("welcome to my website");

//Q:2
// alert("Error! Please entre a valid password");

//Q:3
// alert("Welcome to JS land...<br>happy coding");

//Q:4
// alert("Welcome to JS land...);
// alert("Happy coding!");

//Q:5
// console.log("Hello..I can run JS through my web browser's console"); 
//Q:6
//yes we can use

//Q:7
//All of them