//Chapter:3
//Q:1
// var age=15;
// alert("I am "+age+" years old");

//Q:2
// var n=14;
// alert("You have visited this side "+n+" times");

//Q:3
// var birth_year=1999;
// document.write("My birth year is "+birth_year);
// document.write("<br> Data type of my decleared variable is number");

//Q:4
// var name=prompt("what is your name?");
// var product=prompt("what you want to buy?");
// var quan=prompt("how many products a visitor wants to order?");
// document.write(name+" ordered "+quan+" "+product+"(s) on XYZ Clothing store");