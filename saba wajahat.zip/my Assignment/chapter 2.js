//CHAPTER:2
//Q:1
// var username;

//Q:2
// var myname="shaheen ansari";

//Q:3
// var message;
// message="hello world";
// alert(message);

//Q:4
// var a=prompt ("Entre name");
// var b= prompt("Entre your age..");
// var c=prompt("whose course applied?");
// alert(b+" years old");
// alert(a);
// alert("Certified for "+c);

//Q:5
// var word="Pizza";
// alert("Pizza"+<br>+"Pizz"+<br>+"Piz"+<br>+"Pi"+<br>+"P";

//Q:6
// var email=" example@example.com";
// alert("My email address is"+email);

//Q:7
// var book= "A smarter way to learn JavaScript";
// alert("I am tryiny to learn from the book "+book);

//Q:8
// document.write("Yah! I canwrite HTML content through Java Script");

//Q:9
// var logo="▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬";
// alert(logo);