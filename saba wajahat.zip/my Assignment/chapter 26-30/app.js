//task 1:
// var number=3.45214;
// var r=Math.round(number);
// var f=Math.floor(number);
//  var c=Math.ceil(number);
// document.write("<div style="+"border: 2px; background-color: antiquewhite;"+">Number:"+number+"<br>round off value:"+r+"<br>floor value:"+f+"<br>ceil value:"+c+" </div>");

//task 2:
// var number=-2.673;
// var r=Math.round(number);
// var f=Math.floor(number);
//  var c=Math.ceil(number);
// document.write("<div style="+"border: 2px; background-color: antiquewhite;"+">Number:"+number+"<br>round off value:"+r+"<br>floor value:"+f+"<br>ceil value:"+c+" </div>");

//task 3:
// var num=-4;
// var value=Math.abs(num);
// document.write("The absolute value of "+num+" is "+value);
 

//task 4:
// var ran_num=Math.random()*6;
// var round=Math.round(ran_num);
// var ran_num=Math.random()*6;
// var round2=Math.round(ran_num);
// document.write("random dice value: "+round);
// document.write("<br>random dice value: "+round2);

//task 5:
// var ran_num=Math.random()*2;
// var ceil=Math.ceil(ran_num);
// if (ceil===2){
//     document.write(ceil+"<br> <h3>random coin value: Head</h3>");
// }
// else{
//     document.write(ceil+"<br> <h3>random coin value: Tail</h3>");
// }

//task 6:
// var ran_num=Math.random()*100;
// var round=Math.round(ran_num);
// document.write("<div class='second-head'> " + "<h3>" + "random numbers between 1 to 100: "+round+ "</h3>" + "</div>");

//task 7:
// var weight=prompt("Entre your weight in kilogram");
// var con_weight=parseFloat(weight);
// document.write("The weight of user is "+con_veight+" kilogram");

//task 8:
// var input=prompt("Entre a number between 1 to 10");
// var num=parseInt(input);
// var guess=6;
// if(num==guess){
//     alert("Congraulate the user");
// }
// else{
//     alert("Try Again");
// }
