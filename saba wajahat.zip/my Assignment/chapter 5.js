//Chapter:5
//Q:1
// var a=prompt("Entre 1st number...");
// var b=prompt("Enter 2nd number...");
// var x=+a;
// var y=+b;
// var c=(x+y);
// document.write("Sum of "+a+" and "+b+" is "+c);

//Q:2

//for subtraction
// var a=prompt("Entre 1st number...");
// var b=prompt("Enter 2nd number...");
// var x=+a;
// var y=+b;
// var z=x-y; 
// document.write("Answer of "+a+" and "+b+" is "+z);

//for multiply
// var a=prompt("Entre 1st number...");
// var b=prompt("Enter 2nd number...");
// var x=+a;
// var y=+b;
// var c=(x*y);
// document.write("Answer  of "+a+" and "+b+" is "+c);

//for division
// var a=prompt("Entre 1st number...");
// var b=prompt("Enter 2nd number...");
// var x=+a;
// var y=+b;
// var c=(x/y);
// document.write("Sum of "+a+" and "+b+" is "+c);

//for modulus
// var a=prompt("Entre 1st number...");
// var b=prompt("Enter 2nd number...");
// var x=+a;
// var y=+b;
// var c=(x%y);
// document.write("Sum of "+a+" and "+b+" is "+c);

//Q:3
// var num;
// document.write("Value after variable declaration is "+num);
// num=5;
// document.write("<br> Initial value "+ num);
// num=++num;
// document.write("<br>Value after increment is "+num);
// num=num+7;
// document.write("<br>Value after addition is "+num);
// num=--num;
// document.write("<br>Value after decrement is "+num);
// num=num%3;
// document.write("<br>The remainder is "+num);

//Q:4
// var a=600;
// var b=5*a;
// document.write("Total cost to buying 5 tickets to a movie is "+b+"PKR");

//Q:5
// var a=4;
// document.write("Table of 4<br><br><br>");
// for(var i=1;i<=10;i++){
//     document.write(a+"x"+i+"="+a*i+"<br>");
// }

//Q:6
// var celcius=25;
// var foren=(celcius*9/5)+32;
// document.write(celcius+"oC"+" is "+foren+"oF<br>");

// var f=70;
// var cel=(f-32)*5/9;
// document.write(f+"oF"+" is "+cel+"oC<br>");

//Q:7
// var a=650;
// var b=100;
// var q1=3;
// var q2=7;
// var c=100;
// var x=(a*q1)+(b*q2)+c;
// document.write(" Price of item 1 is "+a);
// document.write("<br> Price of item 2 is "+b);
// document.write(" <br> Ordered quantity of item 1  is "+q1);
// document.write("<br> Ordered Quantity of item 2  is "+q2);
// document.write("<br> Shipping charges  is "+c);
// document.write(" <br><br><br> Total cost of your ordered is "+x);

//Q:8
// var total=980;
// var obtain=804;
// var percent=(obtain/total)*100;
// document.write("Total Marks: "+total);
// document.write("<br>Marks Obtain: "+obtain);
// document.write("<br>Percentage: "+percent);

//Q:9
// var us=10;
// var saudi=25;
// var us_value=104.80;
// var saudi_value=28;
// var pkr=(us*us_value)+(saudi*saudi_value);
// document.write("Total Curruncy in PKR: "+pkr);

//Q:10

// var value=5;
// var res=value+5*10/2;
// document.write("The result is "+res);

//Q:11
// document.write("<h1> Age</h1>")
// var current_year=2020;
// var birth_year=1999;
// var $age=current_year-birth_year;
// document.write("Current Year:"+current_year);
// document.write("<br>Birth Year: "+birth_year)
// document.write("<br>Your age is "+$age);

//Q:12
// var radius=20;
// var curcumference=2*3.142*radius;
// var area=3.142*radius*radius;
// document.write("<h1> The Geometrizer</h1>");
// document.write("<br>Radius of circle is "+radius);
// document.write("<br>Cercumferrence of the circle is "+curcumference);
// document.write("<br>Area of a Circle is "+area);

//Q:13
// var fav_snake="chocolate chips", current_age=15, max_age=65, per_day_snake=3 ;
// var calculate=(max_age-current_age)*per_day_snake;
// document.write("<h1>The Lifetime Supply Calculator:</h1>");
// document.write("<br><br>favourite Snake:"+fav_snake);
// document.write("<br>Current Age:"+current_age);
// document.write("<br>Estimate Maximum age:"+max_age);
// document.write("<br>Amount of Snake per day:"+per_day_snake);
// document.write("<br>You will need "+calculate+" chocolate chips to last you until the ripe old age of "+max_age);


