// CHAPTER 17-20
//Q:1
// var mul_arr=[["ali"],20,"b"]
// alert(mul_arr);

//Q:2
// var arr1=[[0 , 1 , 2 , 3],[1,0,1,2],[2,1,0,1]];
// document.write(arr1[0]+"<br>"+arr1[1]+"<br>"+arr1[2]);

//Q:3
// for(var i=1;i<=10;i++){
//     document.write(i +"<br>");

// }

// Q:4
// var a=prompt("Entre a number to show its multiplication table");
// var b=prompt("Entre length of multiplication table");
// var x=a;
// var y=b;
// for(var i=1;i<=b;i++){
//     document.write(a+"x"+i+"="+a*i+"<br>");
// }
 
// Q:5
// var fruits = ["apple", "banana", "mango", "orange","strawberry"];
// for(var i=0;i<fruits.length;i++){
//     document.write(fruits[i]+"<br>");
    

// }
// for(var i=0;i<fruits.length;i++){
//     document.write("Element at index "+i+" is "+fruits[i]+"<br>");
    

// }
//Q:6
//A
// document.write("Counting: <br><br>");
// for(var i=1;i<=15;i++){
//     document.write(i+",");
// }
// //B
// document.write("<br><br>Reverse Counting: <br><br>");
// for(var i=10;i>=1;i--){
//     document.write(i+",");
// }
//C
// document.write("<br><br>Even <br><br>");
// for(var i=0;i<=20;i+2){
//     document.write(i+",");
// }
//D
// document.write("<br><br>Odd <br><br>");
// for(var i=1;i<=20;i+2){
//     document.write(i+",");
// }
//E
// document.write("<br><br>Series <br><br>");
// for(var i=2;i<=20;i+2){
//     document.write(i+"k, "); 
// }

//Q:7
// var array=["cake","apple pie","cookie","chips","patties"]
// var a=prompt();
// for(var i=0;i<array.length;i++){
//     if(a===array[i]){
//         alert(a+"is available at index "+i+" in our bakery");
//     }
//     else{
//         alert("we are sorry"+a+" is not available in our bakery");
//     }

// }

//Q:8
// var array = [3 , 6, 2, 56, 32, 5, 89, 32];
// var largest= 0;
// document.write("Array item:<br>"+array);

// for (i=0; i<=largest;i++){
//     if (array[i]>largest) {
//         var largest=array[i];
//     }
// }
// document.write("<br>The largest number is "+largest);




 

//Q:9
// var array = [3 , 6, 2, 56, 32, 5, 89, 32];
// var smallest= 100;
// document.write("Array item:<br>"+array+"<br>");

// for (i=0; i<=smallest;i++){
//     if (array[i]<smallest) {
//         var smallest=array[i];
//     }
// }
// document.write("The smallest number is "smallest);


//Q:10
// for(var i=1;i<=100;i++){
//     if(i%5==0){
//         document.write(i+" ,")
//     }
// }




    